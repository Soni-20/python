import graphics.3d graphics
from graphics.rectangle import rectangle
from graphics.circle import circle
