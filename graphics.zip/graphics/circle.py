def circle(x):
    a=(3.14)*r*r
    p=2*(3.14)*r
    print("area of circle:",a)
    print("perimeter of circle:",p)
r=int(input("enter the radius of circle"))
circle(r)

