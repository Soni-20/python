def rectangle(x):
    a=l*b
    p=2*(l+b)
    print("area of rectangle:",a)
    print("perimeter of rectangle:",p)
l=int(input("enter the length of rectangle"))
b=int(input("enter the breadth of rectangle"))
rectangle(l)

