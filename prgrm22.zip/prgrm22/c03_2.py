from graphics import *
from graphics.3d graphics import cuboid,sphere
from graphics import rectangle,circle
graphics.rectangle.rectangle()
graphics.circle.circle()
graphics.3d graphics.cuboid.cuboid()
graphics.3d graphics.sphere.sphere()
