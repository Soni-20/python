from graphics.3d graphics.cuboid import cuboid
from graphics.3d graphics.sphere import sphere
