def sphere(x):
    a=(4*(3.14)*r*r)/3
    p=4*(3.14)*r
    print("area of sphere:",a)
    print("perimeter of sphere:",p)
r=int(input("enter the radius of sphere"))
sphere(r)
