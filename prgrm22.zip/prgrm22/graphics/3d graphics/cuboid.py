def cuboid(x):
    a=2*(l*b+b*h+h*l)
    p=4*(l+b+h)
    print("area of cuboid:",a)
    print("perimeter of cuboid:",p)
l=int(input("enter the length of sphere"))
b=int(input("enter the breadth of sphere"))
h=int(input("enter the height of sphere"))
cuboid(l)

