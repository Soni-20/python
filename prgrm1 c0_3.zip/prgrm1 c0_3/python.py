from python_packages import first,second
second.tuna_second()
first.tuna()
