def tuna():
    print ("i am from first module")


tuna()

