def tuna ():
    print("i am from second module")


tuna()
